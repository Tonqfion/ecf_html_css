const submitForm = document.querySelector(".submit-btn");

submitForm.addEventListener("submit", submitFunction);

function submitFunction(e) {
  e.preventDefault();
}

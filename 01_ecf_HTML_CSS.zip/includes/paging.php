<section class="paging">
    <div class="container">
        <div class="pagination">
            <a href="#" aria-label="Page précédente"><< </a>
                    <a href="#" class="active" aria-label="Première Page">1</a>
                    <a href="#" aria-label="Deuxième Page">2</a>
                    <a href="#" aria-label="Troisième Page">3</a>
                    <a href="#" aria-label="Page suivante">>></a>
        </div>
    </div>
</section>